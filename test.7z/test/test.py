import os
import flask
import json

app = flask.Flask(__name__)

@app.route('/')
def index():
    filepath = os.path.join(os.path.dirname(__file__), 'main.html')
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()

@app.route('/data')
def data():
    filename = flask.request.args.get('file', 'data.json')
    # 防止目录穿越攻击
    if not filename.endswith('.json') or '/' in filename or '\\' in filename:
        return flask.abort(400)
    filepath = os.path.join(os.path.dirname(__file__), filename)
    if not os.path.exists(filepath):
        return flask.abort(404)
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return flask.jsonify(data)

if __name__ == '__main__':
    app.run()