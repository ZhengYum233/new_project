function loadAndRender(jsonFile) {
    fetch('/data?file=' + encodeURIComponent(jsonFile))
        .then(response => response.json())
        .then(data => {
            // 饼图
            var pieDom = document.getElementById('pieChart');
            var pieChart = echarts.init(pieDom);
            var pieOption = {
                title: { text: '语言占比', left: 'center' },
                tooltip: { trigger: 'item' },
                legend: { orient: 'vertical', left: 'left' },
                series: [
                    {
                        name: '占比',
                        type: 'pie',
                        radius: '50%',
                        data: data,
                    }
                ]
            };
            pieChart.setOption(pieOption);

            // 柱状图
            var columnDom = document.getElementById('columnChart');
            var columnChart = echarts.init(columnDom);
            var categories = data.map(item => item.name);
            var values = data.map(item => item.value);
            var columnOption = {
                title: { text: '语言数量统计', left: 'center' },
                tooltip: {},
                xAxis: {
                    type: 'category',
                    data: categories
                },
                yAxis: {
                    type: 'value'
                },
                series: [{
                    name: '数量',
                    type: 'bar',
                    data: values
                }]
            };
            columnChart.setOption(columnOption);
        });
}

// 页面加载时默认加载第一个
document.addEventListener('DOMContentLoaded', function() {
    var select = document.getElementById('dataSelect');
    loadAndRender(select.value);
    select.addEventListener('change', function() {
        loadAndRender(this.value);
    });
});