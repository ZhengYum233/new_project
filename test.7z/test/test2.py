import sqlite3
import os
import csv

# 数据库文件名
db_path = os.path.join(os.path.dirname(__file__), 'test.db')
csv_path = os.path.join(os.path.dirname(__file__), 'data.csv')

conn = sqlite3.connect(db_path)
cur = conn.cursor()

# # 创建表
# cur.execute('''
# CREATE TABLE IF NOT EXISTS firstTable (
#     name TEXT PRIMARY KEY,
#     value INTEGER NOT NULL
# )
# ''')

# # 清空表
# cur.execute('DELETE FROM firstTable')

# # 读取CSV并插入数据
# with open(csv_path, 'r', encoding='utf-8') as f:
#     reader = csv.DictReader(f)
#     for row in reader:
#         cur.execute('INSERT INTO firstTable (name, value) VALUES (?, ?)', (row['name'], int(row['value'])))
cur.execute('''select * from firstTable''')
rows = cur.fetchall()
for row in rows:
    print(row)
conn.commit()
conn.close()
print("firstTable 已创建并导入数据。")