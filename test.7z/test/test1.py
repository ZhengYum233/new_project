import os
import flask
import sqlite3

app = flask.Flask(__name__)

@app.route('/')
def index():
    filepath = os.path.join(os.path.dirname(__file__), 'main.html')
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()

@app.route('/data')
def data():
    db_path = os.path.join(os.path.dirname(__file__), 'test.db')
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()
    cur.execute('SELECT name, value FROM firstTable')
    rows = cur.fetchall()
    conn.close()
    # 转换为字典列表
    result = [{'name': row[0], 'value': row[1]} for row in rows]
    return flask.jsonify(result)

if __name__ == '__main__':
    app.run()